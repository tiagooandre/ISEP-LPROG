package eapli.base.productmanagement.application;

public class ProductSort {

/*    public List<Product> byPrice(List<Product> prodPrice) {
        Collections.sort(prodPrice);
    }*/
}
