package eapli.base.warehousemanagement.repositories;

import eapli.base.warehousemanagement.domain.WAisle;
import eapli.framework.domain.repositories.DomainRepository;

public interface WAisleRepository extends DomainRepository<Long, WAisle> {
}