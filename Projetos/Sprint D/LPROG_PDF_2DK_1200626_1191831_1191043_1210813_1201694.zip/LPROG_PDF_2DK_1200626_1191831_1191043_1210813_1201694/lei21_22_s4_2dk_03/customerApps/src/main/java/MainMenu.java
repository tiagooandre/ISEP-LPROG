import ui.Menu;

public class MainMenu {
    public static void main(String[] args) {
        new Menu().mainMenu();
    }
}
