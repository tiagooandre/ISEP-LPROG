# Rui Gonçalo Sil Gonçalves - 1191831

### Índice das Funcionalidade Desenvolvidas ###

| Sprint | Funcionalidade                   |
|--------|----------------------------------|
| **B**  | [US1001](docs/Sprint%20B/US1001) |
| **B**  | [US1002](docs/Sprint%20B/US1002) |
| **C**  | [US4001](docs/Sprint%20C/US4001) |
| **C**  | [US4002](docs/Sprint%20B/US4002) |
